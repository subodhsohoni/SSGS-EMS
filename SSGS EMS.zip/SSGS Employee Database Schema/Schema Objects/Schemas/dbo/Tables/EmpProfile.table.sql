﻿CREATE TABLE [dbo].[EmpProfile]
(
	EmpId int NOT NULL, 
	EmpEducation NVarChar(MAX) NULL,
	EmpFamily NVarChar(MAX) NULL,
	EmpHobbies NVarChar(MAX) NULL
)
