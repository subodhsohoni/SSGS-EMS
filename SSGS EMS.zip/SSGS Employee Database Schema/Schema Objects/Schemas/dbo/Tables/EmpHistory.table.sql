﻿CREATE TABLE [dbo].[EmpHistory]
(
	EmpId int NOT NULL, 
	RecordedEvent NVarChar(MAX) NOT NULL,
	EventDate Date NOT NULL
)
