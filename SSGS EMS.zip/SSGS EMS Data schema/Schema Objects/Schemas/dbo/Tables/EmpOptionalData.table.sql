﻿CREATE TABLE [dbo].[EmpOptionalData] (
    [EmpId]         INT            NOT NULL,
    [EmpEduInfo]    NVARCHAR (MAX) NULL,
    [EmpFamilyInfo] NVARCHAR (MAX) NULL,
    [EmpHobbies]    NVARCHAR (MAX) NULL
);

